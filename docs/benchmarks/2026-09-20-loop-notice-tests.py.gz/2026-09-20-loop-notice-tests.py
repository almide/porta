#!/usr/bin/env python3
"""Exercise observational loop notices through real WASM and durable replay."""
import http.server
import json
import pathlib
import subprocess
import sys
import tempfile
import threading

porta, agent, tool = [str(pathlib.Path(p).resolve()) for p in sys.argv[1:4]]
NOTICE = 'Recent tool calls repeated the same arguments'
requests = []
mode = 'repeat'
limit = 6


class Model(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        requests.append(body)
        count = sum(m['role'] == 'tool' for m in body['messages'])
        if count >= limit:
            message = {'role': 'assistant', 'content': 'complete'}
        else:
            calls = []
            for offset in range(3 if mode == 'batch' else 1):
                index = count + offset
                name = 'read_file' if mode in ('changing', 'cycle') and (mode == 'changing' or index % 2) else 'write_file'
                arguments = {'path': 'value.txt'}
                if name == 'write_file':
                    arguments['content'] = str(index) if mode == 'arguments' else 'same'
                if mode == 'changing':
                    (work / 'value.txt').write_text(str(index))
                calls.append({'id': f'call-{index}', 'type': 'function', 'function': {
                    'name': name, 'arguments': json.dumps(arguments)}})
            message = {'role': 'assistant', 'tool_calls': calls}
        data = json.dumps({'choices': [{'message': message}]}).encode()
        self.send_response(200)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Model)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
try:
    with tempfile.TemporaryDirectory(prefix='porta-loop-') as directory:
        root = pathlib.Path(directory).resolve()
        work = root / 'work'
        work.mkdir()
        config = root / 'agent.toml'
        base = f'''version=1
[agent]
wasm={json.dumps(agent)}
[model]
endpoint="http://127.0.0.1:{server.server_port}/model"
name="fixture"
[limits]
max_model_calls=12
'''
        for name in ('write_file', 'read_file'):
            base += f'''[[tools]]
name="{name}"
wasm={json.dumps(tool)}
mounts=[{{host="work",guest=".",read_only=false}}]
'''
        config.write_text(base)

        def run(*args, error=None):
            result = subprocess.run([porta, *map(str, args)], capture_output=True, text=True, timeout=15)
            if error:
                assert result.returncode != 0 and error in result.stderr, result
            else:
                assert result.returncode == 0, result.stderr
            return result

        def notices(request):
            return sum(m['role'] == 'user' and m.get('content', '').startswith(NOTICE)
                       for m in request['messages'])

        for mode, limit, expected in [('repeat', 6, 2), ('cycle', 4, 1), ('batch', 3, 1),
                                       ('changing', 6, 0), ('arguments', 6, 0)]:
            requests.clear()
            run('agent', config, '--', 'exercise repeated operations')
            last = requests[-1]
            results = [m for m in last['messages'] if m['role'] == 'tool']
            assert len(results) == limit and notices(last) == expected, (mode, last)
            assert [m['tool_call_id'] for m in results] == [f'call-{i}' for i in range(limit)]
            if mode == 'repeat':
                assert [notices(r) for r in requests] == [0, 0, 0, 1, 1, 1, 2]
            if mode == 'batch':
                assert len(requests) == 2  # No notice between pending batch calls.
        print('PASS: repeated calls and cycles trigger notices; changed arguments/results do not; pending batches finish intact')

        mode, limit = 'cycle', 4
        requests.clear()
        journal = root / 'loop.jsonl'
        run('agent', config, '--record', journal, '--pause-after', '8', '--', 'exercise cycle')
        assert len(requests) == 4
        (work / 'value.txt').write_text('external edit')
        run('agent-resume', config, journal)
        assert len(requests) == 5 and notices(requests[-1]) == 1
        assert (work / 'value.txt').read_text() == 'external edit'
        run('agent-replay', config, journal)
        assert len(requests) == 5 and (work / 'value.txt').read_text() == 'external edit'
        print('PASS: checkpoint reconstruction preserves the notice and completed effects; replay makes no model calls or writes')

        mode, limit = 'repeat', 6
        requests.clear()
        config.write_text(base.replace('max_model_calls=12', 'max_model_calls=3'))
        run('agent', config, '--', 'exercise budget', error='model call budget exceeded')
        assert len(requests) == 3
        print('PASS: loop feedback cannot reset or exceed the host model budget')
finally:
    server.shutdown()
    server.server_close()
    thread.join()
